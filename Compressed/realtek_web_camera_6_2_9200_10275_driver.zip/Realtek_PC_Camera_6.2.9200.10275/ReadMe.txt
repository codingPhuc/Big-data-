----------------------------
Silent Installation Command 
----------------------------
Run "setup.exe /s /f2<path\LogFile>"
i.e. setup.exe /s /f2c:\mylog.log

-------------------------------
Silent Uninstallation Command
-------------------------------
Run "setup.exe /removeonly /s /f1<path\usetup.iss> /f2<path\LogFile>"
i.e. setup.exe /removeonly /s /f1.\usetup.iss /f2c:\mylog.log

--------------------
Support Languages
--------------------
Arabic, Arabic Lebanon, Arabic Saudi Arabia
Basque, Brazilian, Bulgarian, Catalan
Chinese-Traditional-HK, Chinese-Simplified, Chinese-Traditional-TW
Croatian, Czech, Danish, Dutch
English, English-Euro, Estonian, Finnish
French, French/Canadian, German, Greek
Hebrew, Hungarian, Italian
Japanese, Korean, Latvian
Lithuanian, Norwegian, Polish, Portuguese
Romanian, Russian, Slovak, Slovenian
Spanish, Swedish, Thai
Turkish, Ukrainian 
